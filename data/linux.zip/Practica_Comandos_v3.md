# Práctica de Comandos — **V3** (mini‑scripts `.sh` con `for`, `if/else`, `&&`, `||` + `cron`)

> Objetivo: que el alumnado **vea la utilidad real** de crear pequeños ficheros `.sh` y ejecutarlos por línea de comandos para automatizar tareas.

---

## 0) Preparación (imprescindible)
1. Crea una carpeta de trabajo y entra en ella:
   ```bash
   mkdir -p ~/practica_sh_v3 && cd ~/practica_sh_v3
   ```
2. Cada ejercicio creará **un script**. Asegúrate de:
   - Encabezado *shebang* en la primera línea: `#!/usr/bin/env bash`
   - Dar permisos de ejecución: `chmod +x nombre_script.sh`
   - Ejecutar: `./nombre_script.sh`
3. Recomendación: edita con `nano`, `code` o `vim`. Por ejemplo:
   ```bash
   nano 01_for_saludo.sh
   ```

---

## 1) `for`: saludar a cada usuario en una lista
**Fichero:** `01_for_saludo.sh`  
**Conceptos:** bucle `for`, variables de entorno sencillas.

```bash
#!/usr/bin/env bash
# 01_for_saludo.sh — Saluda a cada nombre pasado como argumento
# Uso: ./01_for_saludo.sh Ana Luis "María José"

if [ $# -eq 0 ]; then
  echo "Uso: $0 nombre1 [nombre2 ...]"
  exit 1
fi

for nombre in "$@"; do
  echo "¡Hola, $nombre! 👋"
done
```

**Prueba:**
```bash
chmod +x 01_for_saludo.sh
./01_for_saludo.sh Ana Luis "María José"
```

---

## 2) `if/else`: copia de seguridad si existe el fichero
**Fichero:** `02_ifelse_backup.sh`  
**Conceptos:** `if/else`, comprobación de existencia `-f`.

```bash
#!/usr/bin/env bash
# 02_ifelse_backup.sh — Si existe el fichero, crea una copia con sello temporal
# Uso: ./02_ifelse_backup.sh notas.txt

ORIG="$1"
if [ -z "$ORIG" ]; then
  echo "Uso: $0 fichero"
  exit 1
fi

if [ -f "$ORIG" ]; then
  TS=$(date +"%Y%m%d_%H%M%S")
  DEST="${ORIG}.${TS}.bak"
  cp "$ORIG" "$DEST"
  echo "Copia creada: $DEST"
else
  echo "No existe el fichero '$ORIG'"
fi
```

**Prueba:**
```bash
echo "apuntes" > notas.txt
./02_ifelse_backup.sh notas.txt
ls -1 notas.txt.*.bak
```

---

## 3) `&&` (AND) para encadenar pasos que dependen del anterior
**Fichero:** `03_and_descarga_y_extrae.sh`  
**Conceptos:** operador `&&` (solo ejecuta si el anterior **tuvo éxito**).

```bash
#!/usr/bin/env bash
# 03_and_descarga_y_extrae.sh — Descarga un ZIP y lo extrae si la descarga va bien
# Uso: ./03_and_descarga_y_extrae.sh https://fransdata.com/data/datos.zip

URL="$1"
if [ -z "$URL" ]; then
  echo "Uso: $0 URL_ZIP"
  exit 1
fi

NOMBRE="descarga.zip"
echo "Descargando $URL ..."
curl -L "$URL" -o "$NOMBRE" && unzip -o "$NOMBRE" && echo "¡Listo!"
```

**Idea:** Si `curl` falla, **no** se ejecutará `unzip`.  
**Prueba con un ZIP pequeño** (por ejemplo, uno público de tu elección).

---

## 4) `||` (OR) para ofrecer alternativa cuando algo falla
**Fichero:** `04_or_ping_o_mensaje.sh`  
**Conceptos:** operador `||` (ejecuta la derecha **si falla** la izquierda).

```bash
#!/usr/bin/env bash
# 04_or_ping_o_mensaje.sh — Hace ping a un host, si falla, muestra aviso
# Uso: ./04_or_ping_o_mensaje.sh 8.8.8.8

HOST="$1"
[ -z "$HOST" ] && { echo "Uso: $0 HOST"; exit 1; }

ping -c 2 "$HOST" >/dev/null 2>&1 || echo "No hay conectividad con $HOST"
```

**Prueba:**
```bash
./04_or_ping_o_mensaje.sh 8.8.8.8
./04_or_ping_o_mensaje.sh 203.0.113.123   # host inventado (debería fallar)
```

---

## 5) `for` + `if/else`: limpiar logs antiguos
**Fichero:** `05_for_ifelse_limpiar_logs.sh`  
**Conceptos:** mezclar `for` con condiciones; manejar rutas.

```bash
#!/usr/bin/env bash
# 05_for_ifelse_limpiar_logs.sh — Mueve a 'logs_old/' los .log de más de N días
# Uso: ./05_for_ifelse_limpiar_logs.sh carpeta_donde_buscar Ndias

DIR="$1"
DAYS="$2"

if [ -z "$DIR" ] || [ -z "$DAYS" ]; then
  echo "Uso: $0 carpeta Ndias"
  exit 1
fi

DEST="$DIR/logs_old"
mkdir -p "$DEST"

# Buscar .log modificados hace más de N días
mapfile -t ARCHIVOS < <(find "$DIR" -type f -name "*.log" -mtime +"$DAYS")

if [ ${#ARCHIVOS[@]} -eq 0 ]; then
  echo "No hay logs de más de $DAYS días en $DIR"
else
  for f in "${ARCHIVOS[@]}"; do
    mv "$f" "$DEST"/
    echo "Movido: $f -> $DEST/"
  done
fi
```

**Prueba rápida de laboratorio:**
```bash
mkdir -p sandbox && cd sandbox
echo "hoy" > hoy.log
# simular antiguo
touch -t 202201010101 antiguo.log
cd ..
./05_for_ifelse_limpiar_logs.sh sandbox 30
tree sandbox
```

---

## 6) `&&` + `||`: flujo “éxito / fallo” en una línea
**Fichero:** `06_and_or_build.sh`  
**Conceptos:** patrón `comando && echo OK || echo FAIL` (cuidado con *set -e*).

```bash
#!/usr/bin/env bash
# 06_and_or_build.sh — Simula un build: si compila OK, empaqueta; si no, avisa
# Uso: ./06_and_or_build.sh

mkdir -p build && echo "Compilando..." && sleep 1 && touch build/app.bin \
  && echo "Compilación OK, empaquetando..." && tar -czf build.tgz build \
  || echo "Algo falló durante el proceso"
```

**Prueba:**
```bash
./06_and_or_build.sh
ls -l build.tgz
```

---

## 7) `if/elif/else`: clasificar uso de disco
**Fichero:** `07_ifelif_clasifica_uso.sh`  
**Conceptos:** rangos con `elif` y comando `df`.

```bash
#!/usr/bin/env bash
# 07_ifelif_clasifica_uso.sh — Informa el uso de / en tres niveles
# Uso: ./07_ifelif_clasifica_uso.sh

USO=$(df -h / | awk 'NR==2 {gsub("%",""); print $5}')

if [ "$USO" -lt 50 ]; then
  echo "Uso de disco bajo (${USO}%)."
elif [ "$USO" -lt 80 ]; then
  echo "Uso de disco medio (${USO}%)."
else
  echo "Uso de disco ALTO (${USO}%). ¡Revisa espacio!"
fi
```

**Prueba:**
```bash
./07_ifelif_clasifica_uso.sh
```

---

## 8) `for` práctico: renombrar fotos masivamente
**Fichero:** `08_for_renombra_fotos.sh`  
**Conceptos:** bucle sobre ficheros, expansión de parámetros `${var%.*}` / `${var##*/}`

```bash
#!/usr/bin/env bash
# 08_for_renombra_fotos.sh — Renombra fotos IMG_*.jpg -> foto_0001.jpg ...
# Uso: ./08_for_renombra_fotos.sh carpeta_fotos

DIR="$1"
[ -z "$DIR" ] && { echo "Uso: $0 carpeta_fotos"; exit 1; }

i=1
for f in "$DIR"/IMG_*.jpg; do
  [ -e "$f" ] || { echo "No hay IMG_*.jpg en $DIR"; exit 0; }
  printf -v nuevo "foto_%04d.jpg" "$i"
  mv "$f" "$DIR/$nuevo"
  echo "$f -> $DIR/$nuevo"
  ((i++))
done
```

**Prueba de laboratorio:**
```bash
mkdir -p fotos && touch fotos/IMG_1001.jpg fotos/IMG_1002.jpg
./08_for_renombra_fotos.sh fotos
ls -1 fotos
```

---

## 9) `if/else` + `&&`/`||`: chequeo de servicio web
**Fichero:** `09_check_web.sh`  
**Conceptos:** `curl -s -o /dev/null -w "%{http_code}"`, control de códigos.

```bash
#!/usr/bin/env bash
# 09_check_web.sh — Comprueba un endpoint y registra el resultado
# Uso: ./09_check_web.sh https://example.org

URL="$1"
LOG="webcheck.log"
[ -z "$URL" ] && { echo "Uso: $0 URL"; exit 1; }

CODE=$(curl -s -o /dev/null -w "%{http_code}" "$URL")
if [ "$CODE" -eq 200 ]; then
  echo "$(date) OK $URL ($CODE)" | tee -a "$LOG"
else
  echo "$(date) FAIL $URL ($CODE)" | tee -a "$LOG"
fi
```

**Prueba:**
```bash
./09_check_web.sh https://example.org
cat webcheck.log
```

---

## 10) Bonus corto: `for` sobre líneas de un fichero
**Fichero:** `10_for_lineas.sh`  
**Conceptos:** leer línea a línea con `while read` (alternativa al `for`).

```bash
#!/usr/bin/env bash
# 10_for_lineas.sh — Lee un fichero y enumera sus líneas
# Uso: ./10_for_lineas.sh lista.txt

FILE="$1"
[ -z "$FILE" ] && { echo "Uso: $0 fichero"; exit 1; }

n=1
while IFS= read -r linea; do
  echo "$n: $linea"
  ((n++))
done < "$FILE"
```

**Prueba:**
```bash
printf "uno\ndos\ntres\n" > lista.txt
./10_for_lineas.sh lista.txt
```

---

# ¿Por qué usar ficheritos `.sh`?
- Reutilizas comandos habituales con **un doble clic** o un solo `./script.sh`.
- Capturas tu **conocimiento operativo** y lo compartes con tu equipo.
- Se pueden **versionar** en Git y **programar** con `cron` (automatización).

---

# `cron`: programar tareas automáticas
`cron` es el planificador clásico de Unix/Linux. Permite ejecutar scripts a horas y frecuencias fijas.

## 1) Editar tu crontab
```bash
crontab -e    # abre el editor para tu usuario
crontab -l    # lista tus tareas programadas
```

## 2) Formato de una línea de `crontab`
```
# ┌ min (0-59)
# │ ┌ hora (0-23)
# │ │ ┌ día del mes (1-31)
# │ │ │ ┌ mes (1-12)
# │ │ │ │ ┌ día semana (0-7, 0/7 = domingo)
# │ │ │ │ │
# * * * * *  comando_a_ejecutar
```

## 3) Ejemplos útiles
- Ejecutar `09_check_web.sh` **cada 5 minutos** y guardar log:
  ```
  */5 * * * * /bin/bash ~/practica_sh_v3/09_check_web.sh https://example.org >> ~/practica_sh_v3/cron.log 2>&1
  ```
- Limpiar logs antiguos **a las 03:00** cada día:
  ```
  0 3 * * * /bin/bash ~/practica_sh_v3/05_for_ifelse_limpiar_logs.sh ~/practica_sh_v3/sandbox 30 >> ~/practica_sh_v3/cron.log 2>&1
  ```
- Ejecutar un script **cada lunes a las 08:15**:
  ```
  15 8 * * 1 /bin/bash ~/practica_sh_v3/07_ifelif_clasifica_uso.sh >> ~/practica_sh_v3/cron.log 2>&1
  ```
- Atajos especiales:
  ```
  @reboot  /bin/bash ~/inicio.sh              # al arrancar el sistema
  @daily   /bin/bash ~/backup_diario.sh       # una vez al día
  @hourly  /bin/bash ~/tarea_cada_hora.sh
  ```

## 4) Consejos de producción
- Usa rutas **absolutas** en `crontab` (`/bin/bash`, `~/...`).
- Redirige salida y errores: `>> logfile 2>&1`.
- Asegura **permisos de ejecución** y variables de entorno mínimas en el propio script (no dependas del `.bashrc`).
- Añade **registros (logs)** con `echo "$(date) ..."` o `logger`.
- Comprueba el *status* de `cron` (por ejemplo, `systemctl status cron` o `crond`).

---

## Checklist de entrega
- [ ] 10 scripts creados con su *shebang* y permisos `+x`.
- [ ] Probado cada script con un ejemplo mínimo.
- [ ] Añadida al menos **1** tarea en `crontab` y verificado su log.
- [ ] Subida la carpeta al repositorio (opcional).

---

**¡Listo!** Con estos mini‑ficheros `.sh` ya has practicado `for`, `if/else`, `&&` y `||`, y has visto cómo **automatizar** su ejecución con `cron`.
