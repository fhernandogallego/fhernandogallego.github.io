
# Práctica de Linux por Línea de Comandos
**Objetivo:** poner en práctica todos los comandos y conceptos de cmd con un único hilo conductor.

> **Cómo usar esta práctica**  
> - Copia los bloques `bash` en tu terminal (Linux/macOS).  
> - Si un comando requiere privilegios, añade `sudo` (lo indicamos cuando aplica).  
> - Puedes ejecutarla en tu `$HOME` sin afectar al sistema (salvo las partes marcadas como “requiere *sudo*”).

---

## 0) Preparación del entorno de trabajo (seguro en tu HOME)
Creamos una “mini infraestructura” para jugar sin tocar archivos del sistema.

```bash
# 0.1) Punto de partida
pwd
mkdir -p ~/laboratorio_linux/{datos,logs,bin,backups,proyectos/app/{input,output}}
tree ~/laboratorio_linux -L 2

# 0.2) Archivos de ejemplo
cd ~/laboratorio_linux/datos
printf "usuario,ip,evento\nana,192.168.1.10,login_ok\nluis,10.0.0.7,login_fail\nana,192.168.1.11,logout\n" > accesos.csv
printf "error: disco lleno\ninfo: tarea completada\nwarn: temperatura alta\n" > sistema.log
printf "uno\ndos\ntres\ncuatro\ncinco\n" > numeros.txt
printf "192.168.0.1 - ok\n10.12.12.12 - ok\n172.16.0.8 - warn\ntexto no ip\n" > trazas.txt

# 0.3) Un script sencillo
cd ~/laboratorio_linux/bin
printf '#!/usr/bin/env bash\necho "Hola, $USER. Hoy es $(date)"\n' > hola.sh
chmod +x hola.sh
~/laboratorio_linux/bin/hola.sh
```

**Comandos implicados:** `pwd`, `mkdir -p`, `tree`, `cd`, `printf`/`echo`, `chmod`, `date`.

---

## 1) Navegación, ayuda y atajos
```bash
# 1.1) Dónde estamos y qué hay
pwd
ls -lah ~/laboratorio_linux
ls -l ~/laboratorio_linux/datos

# 1.2) Cambios de directorio frecuentes
cd ~/laboratorio_linux/proyectos/app/input
cd ..           # sube un nivel
cd -            # vuelve al directorio anterior
cd              # HOME

# 1.3) Ayuda y opciones
man ls | head -n 20
ls --help | head -n 20

# 1.4) Historial y reutilización
history | tail -n 5
!!        # repite el último comando
!5        # (ejemplo) ejecuta la entrada nº5 del history
```

**Comandos implicados:** `ls`, `pwd`, `cd`, `man`, `--help`, `history`, `!!`, `!n`.

> **Tip:** Autocompletado con `Tab` y búsqueda incremental con `Ctrl+r` te aceleran muchísimo.

---

## 2) Gestión básica de archivos y directorios
```bash
cd ~/laboratorio_linux

# 2.1) Crear y copiar/mover
touch datos/README.txt
cp datos/README.txt backups/README.copia.txt
mv backups/README.copia.txt backups/README.txt

# 2.2) Ver contenido
cat datos/sistema.log
head -n 2 datos/accesos.csv
tail -n 3 datos/numeros.txt

# 2.3) Borrado (con.confirmación)
rm -i backups/README.txt

# 2.4) Resumen rápido
wc -lwc datos/accesos.csv
```

**Comandos implicados:** `touch`, `cp`, `mv`, `cat`, `head`, `tail`, `rm -i`, `wc`.

---

## 3) Permisos, propietarios y usuarios (simulación)
> En tu HOME puedes practicar permisos sin *sudo*. Cambiar propietario o gestionar usuarios sí requiere privilegios.

```bash
cd ~/laboratorio_linux/datos

# 3.1) Permisos: sólo tú puedes leer/escribir
touch secreto.txt
chmod 600 secreto.txt
ls -l secreto.txt

# 3.2) Permisos más abiertos (rw-r--r--)
chmod 644 secreto.txt
ls -l secreto.txt
```

**Comandos implicados:** `chmod`, `ls -l`.

> **Si quieres practicar propietarios y cuentas (requiere sudo):**
```bash
# Cambiar propietario (ejemplo): sudo chown tuusuario:tuusuario secreto.txt
# Crear usuario:             sudo useradd demo_user
# Eliminar usuario:          sudo userdel demo_user
```
**Comandos implicados (con *sudo*):** `chown`, `useradd`, `userdel`.

---

## 4) Búsqueda y localización de archivos/binaries
```bash
# 4.1) Rutas de ejecutables
which bash
whereis ls

# 4.2) Buscar por nombre desde un directorio
find ~/laboratorio_linux -type f -name "*.txt"

# 4.3) Buscar por tamaño/modificación
find ~/laboratorio_linux -type f -size -1k -printf "%p %k KB\n" 2>/dev/null || true

# 4.4) Base de datos de localización (puede requerir sudo para 'updatedb')
# locate suele funcionar tras tener la base creada por el sistema; si no:
# sudo updatedb
locate hola.sh | head -n 5 || true
```

**Comandos implicados:** `which`, `whereis`, `find`, `locate`, `updatedb`.

---

## 5) Grep, expresiones regulares y búsqueda recursiva
```bash
cd ~/laboratorio_linux/datos

# 5.1) Coincidencias simples
grep login accesos.csv

# 5.2) Sensible/insensible a mayúsculas
grep -i ERROR sistema.log

# 5.3) Recursivo por directorios
grep -r "ok" ..

# 5.4) Expresiones regulares (IPs muy básicas)
grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}" trazas.txt
```

**Comandos implicados:** `grep`, `grep -r`, `grep -E`.

---

## 6) Enlaces duros y simbólicos + metadatos
```bash
cd ~/laboratorio_linux

# 6.1) Archivo original
printf "config=v1\n" > datos/conf.ini

# 6.2) Enlace duro (mismo inodo)
ln datos/conf.ini datos/conf.hardlink.ini
ls -li datos/conf.*

# 6.3) Enlace simbólico
ln -s datos/conf.ini datos/conf.link.ini
ls -l datos/conf.link.ini
readlink -f datos/conf.link.ini
cat datos/conf.link.ini
```

**Comandos implicados:** `ln` (duro), `ln -s` (simbólico), `ls -li`, `readlink`, `cat`.

---

## 7) Wildcards, expansión de llaves y globbing
```bash
cd ~/laboratorio_linux/datos

# 7.1) Crear varios archivos de golpe
touch reporte_2024_01.log reporte_2024_02.log reporte_2024_10.log
touch notas_a.txt notas_b.txt notas_c.txt

# 7.2) Corchetes y comodines
ls reporte_2024_0?.log
ls notas_[ab].txt

# 7.3) Expansión de llaves
touch proyecto_{alpha,beta,gamma}.md
ls proyecto_*.md
```

**Comandos implicados:** comodines de shell `* ? [] {}` y `touch`, `ls`.

---

## 8) Visualización y monitorización de logs
```bash
cd ~/laboratorio_linux/datos

# 8.1) Últimas líneas
tail -n 10 sistema.log
head -n 2 sistema.log

# 8.2) Seguimiento en tiempo real (Ctrl+C para salir)
# En otra terminal, añade una línea:  echo "info: pulso $(date)" >> ~/laboratorio_linux/datos/sistema.log
tail -f sistema.log
```

**Comandos implicados:** `tail`, `head`, `tail -f`, `date`, `echo`.

---

## 9) Transformación rápida de texto (bonus útil)
```bash
cd ~/laboratorio_linux/datos

# 9.1) Extraer la columna de usuarios del CSV (separador coma)
cut -d',' -f1 accesos.csv | tail -n +2

# 9.2) Ordenar y quitar duplicados
cut -d',' -f1 accesos.csv | tail -n +2 | sort | uniq

# 9.3) Sustituciones simples
echo "Linux ES POTENTE" | tr 'A-Z' 'a-z'
```

**Comandos implicados:** `cut`, `sort`, `uniq`, `tr`, `echo`.

---

## 10) Propiedades de archivos y tipos
```bash
cd ~/laboratorio_linux/datos
file accesos.csv
stat accesos.csv | head -n 8
```

**Comandos implicados:** `file`, `stat` (si está disponible).

---

## 11) Alias y personalización temporal de la shell
```bash
# 11.1) Alias temporal para la sesión actual
alias ll='ls -lh --group-directories-first'
ll ~/laboratorio_linux

# 11.2) Hacerlo persistente (opcional): añade a ~/.bashrc y recarga
echo "alias ll='ls -lh --group-directories-first'" >> ~/.bashrc
source ~/.bashrc
```

**Comandos implicados:** `alias`, `source`.

---

## 12) Mensajería del sistema y apagados (simulación)
> Estas acciones pueden necesitar *sudo* y afectan a todo el sistema: pruébalas **sólo** en entornos controlados.

```bash
# 12.1) Aviso a usuarios conectados (requiere sudo en la mayoría de sistemas)
# echo "Mantenimiento en 15 min" | sudo wall

# 12.2) Programar apagado y cancelarlo
# sudo shutdown +15 "Apagado programado por mantenimiento"
# sudo shutdown -c

# 12.3) Reinicio inmediato (¡peligroso!)
# sudo reboot
```

**Comandos implicados:** `wall`, `shutdown`, `reboot`.

---

## 13) Reto integrador (mini flujo real)
**Objetivo:** detectar IPs que aparecen en `trazas.txt`, guardarlas únicas ordenadas, contarlas, y mover el resultado versiónado a `output` con enlace simbólico “actual”.

```bash
cd ~/laboratorio_linux/proyectos/app

# 13.1) Extraer IPs únicas y ordenadas desde datos/trazas.txt
grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}" ../../datos/trazas.txt | sort | uniq > output/ips_v1.txt

# 13.2) Contar cuántas IPs
wc -l output/ips_v1.txt

# 13.3) Crear una nueva versión y un enlace simbólico 'actual'
cp output/ips_v1.txt output/ips_v2.txt
ln -sfn output/ips_v2.txt output/ips_actual.txt
readlink -f output/ips_actual.txt
ls -l output/ips_*.txt output/ips_actual.txt
cat output/ips_actual.txt
```

**Comandos implicados:** `grep -Eo`, `sort`, `uniq`, `wc`, `cp`, `ln -sfn`, `readlink`, `ls -l`, `cat`.

---

## 14) Limpieza opcional
```bash
# Si quieres borrar el laboratorio entero (¡cuidado!):
rm -rf ~/laboratorio_linux
```

---

### Apéndice A: Tabla de comandos cubiertos
- **Navegación y listados:** `pwd`, `cd`, `ls`, `tree`
- **Archivos y texto:** `touch`, `cat`, `head`, `tail`, `tail -f`, `wc`, `echo`, `printf`
- **Copiar/mover/borrar:** `cp`, `mv`, `rm`
- **Permisos/propiedad:** `chmod`, `chown`*
- **Usuarios:** `useradd`*, `userdel`* (*requieren `sudo` normalmente*)
- **Búsqueda:** `which`, `whereis`, `find`, `locate`, `updatedb`, `grep`, `grep -r`, `grep -E`
- **Enlaces y rutas:** `ln`, `ln -s`, `readlink`, `ls -li`
- **Tipos y metadatos:** `file`, `stat`
- **Wildcards/expansión:** `* ? [] {}`
- **Transformaciones texto:** `cut`, `sort`, `uniq`, `tr`
- **Shell/entorno:** `history`, `!!`, `!n`, `alias`, `source`, `man`, `--help`
- **Fecha y mensajes:** `date`, `wall`
- **Energía:** `shutdown`, `reboot`

> Con esta práctica tienes **actividades resueltas** y datos de muestra auto-generados. Puedes modificar los ficheros en `~/laboratorio_linux/datos` para crear tus propias variantes.
