
# Práctica de Línea de Comandos (versión ampliada T2–T5)
**Objetivo:** practicar, con soluciones guiadas, los comandos y conceptos habituales que aparecen en **Tema 2.1, 2.2, 3.1, 3.2, 4 y 5**.  
Todo se hace **por línea de comandos** y con **datos de ejemplo** generados al vuelo, para que el guion tenga sentido de principio a fin.

> Puedes ejecutar todo en tu `$HOME`. Los pasos marcados como *(requiere sudo)* deben hacerse en una máquina de pruebas.

---

## 0) Preparación del “laboratorio” en tu HOME
```bash
# Punto de partida
pwd
mkdir -p ~/lab_cli/{datos,logs,bin,backups,proyectos/app/{input,output},tmp}
cd ~/lab_cli/datos

# Datos de ejemplo
printf "id,usuario,ip,evento\n1,ana,192.168.1.10,login_ok\n2,luis,10.0.0.7,login_fail\n3,ana,192.168.1.11,logout\n" > accesos.csv
printf "2025-09-01 info sistema iniciado\n2025-09-02 warn temperatura alta\n2025-09-03 error disco lleno\n" > sistema.log
printf "uno\ndos\ntres\ncuatro\ncinco\n" > numeros.txt
printf "192.168.0.1 - ok\n10.12.12.12 - ok\n172.16.0.8 - warn\ntexto no ip\n" > trazas.txt

# Script útil
cd ~/lab_cli/bin
printf '#!/usr/bin/env bash\necho "Hola, $USER. Hoy es $(date)" \n' > hola.sh
chmod +x hola.sh
~/lab_cli/bin/hola.sh
```

**Cubrimos:** `pwd`, `mkdir -p`, `cd`, `printf`, `chmod`, `date`.

---

## 1) Navegación, ayuda y shell básica
```bash
cd ~/lab_cli
ls -lah
tree -L 2 . 2>/dev/null || ls -R | head -n 50

# Ayuda
man ls | head -n 10
ls --help | head -n 10

# Historial y atajos
history | tail -n 5
!!       # repite último
!n       # ejecuta la entrada n del history
```

**Cubrimos:** `ls`, `tree`, `man`, `--help`, `history`, `!!`, `!n`.

---

## 2) Archivos: crear, copiar, mover, borrar y contar
```bash
cd ~/lab_cli

# Crear y copiar
touch datos/README.txt
cp datos/README.txt backups/README.copia.txt
mv backups/README.copia.txt backups/README.txt

# Ver contenido
cat datos/sistema.log
head -n 2 datos/accesos.csv
tail -n 3 datos/numeros.txt
nl -ba datos/numeros.txt      # numera líneas
wc -lwc datos/accesos.csv

# Borrado con confirmación
rm -i backups/README.txt
```

**Cubrimos:** `touch`, `cp`, `mv`, `cat`, `head`, `tail`, `nl`, `wc`, `rm -i`.

---

## 3) Permisos, propietarios, umask y usuarios (simulación)

```bash
cd ~/lab_cli/datos
touch secreto.txt
chmod 600 secreto.txt      # rw-------
ls -l secreto.txt
chmod 644 secreto.txt      # rw-r--r--
umask                      # ver máscara actual
```

> *(requiere sudo)* para propietario/usuarios:

```bash
sudo chown tuusuario:tuusuario secreto.txt
sudo useradd demo_user && sudo userdel demo_user
```

**Cubrimos:** `chmod`, `ls -l`, `umask`, `chown`, `useradd`, `userdel`.

---

## 4) Búsqueda: which/whereis/find/locate/grep
```bash
which bash
whereis ls
find ~/lab_cli -type f -name "*.txt"
find ~/lab_cli -type f -size -1k -printf "%p %k KB\n" 2>/dev/null || true

# locate depende de la base del sistema (puede requerir sudo updatedb)
locate hola.sh | head -n 3 || true

# grep básico, recursivo y con regex
cd ~/lab_cli/datos
grep login accesos.csv
grep -i error sistema.log
grep -r "ok" ..
grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}" trazas.txt
```

**Cubrimos:** `which`, `whereis`, `find`, `locate`, `updatedb`, `grep`, `grep -r`, `grep -E`.

---

## 5) Redirecciones, pipes, tee y xargs
```bash
cd ~/lab_cli/datos

# Redirecciones
echo "nueva línea" >> sistema.log
sort numeros.txt > ../tmp/ordenados.txt
cat ../tmp/ordenados.txt 2>../logs/errores.log

# Pipes y tee
cut -d',' -f2 accesos.csv | tail -n +2 | sort | uniq | tee ../tmp/usuarios_unicos.txt

# xargs (aplicar acción a lista)
printf "proyecto_alpha.md\nproyecto_beta.md\n" > ../tmp/nombres.txt
cat ../tmp/nombres.txt | xargs -I{} touch {}
ls proyecto_*.md
```

**Cubrimos:** `>`, `>>`, `2>`, `|`, `tee`, `xargs`, `cut`, `sort`, `uniq`.

---

## 6) sed y awk (transformaciones)
```bash
cd ~/lab_cli/datos

# sed: sustitución in-place con copia de seguridad
sed -i.bak 's/warn/aviso/g' sistema.log
diff -u sistema.log.bak sistema.log || true

# awk: filtrar filas de accesos con login_ok y sacar usuario:ip
awk -F',' 'NR>1 && $4=="login_ok" {print $2 ":" $3}' accesos.csv > ../tmp/users_ok.txt
cat ../tmp/users_ok.txt
```

**Cubrimos:** `sed`, `awk`, `diff`.

---

## 7) Enlaces, globbing y expansión de llaves
```bash
cd ~/lab_cli
printf "config=v1\n" > datos/conf.ini

ln datos/conf.ini datos/conf.hard.ini   # hardlink
ln -s datos/conf.ini datos/conf.sym.ini # symlink

ls -li datos/conf.*
readlink -f datos/conf.sym.ini

cd datos
touch reporte_2025_{01..03}.log notas_{a,b,c}.txt
ls reporte_2025_0?.log
ls notas_[ab].txt
```

**Cubrimos:** `ln`, `ln -s`, `ls -li`, `readlink`, globbing `{ } [ ] ?`.

---

## 8) Archivos y compresión: tar, gzip, bzip2, zip
```bash
cd ~/lab_cli

# tar + gzip
tar -czf backups/datos_$(date +%F).tgz datos
tar -tzf backups/datos_*.tgz | head -n 5

# tar + bzip2
tar -cjf backups/datos_$(date +%F).tbz datos
tar -tjf backups/datos_*.tbz | head -n 5

# zip
zip -r backups/datos.zip datos
unzip -l backups/datos.zip | head -n 5
```

**Cubrimos:** `tar -czf/-cjf`, `tar -t*`, `zip`, `unzip`.

---

## 9) Sistema de ficheros y disco: df/du/file/stat
```bash
df -h | head -n 10
du -sh ~/lab_cli/datos
file ~/lab_cli/datos/accesos.csv
stat ~/lab_cli/datos/accesos.csv | head -n 8
```

**Cubrimos:** `df`, `du`, `file`, `stat`.

---

## 10) Procesos, jobs y señales
```bash
# Información de procesos
ps aux | head -n 5
ps -ef | head -n 5
top -b -n 1 | head -n 5

# Jobs (simulación con sleep)
(sleep 60) &
jobs
bg %1
fg %1  # Ctrl+C para terminar

# Señales
(sleep 120) &
PID=$!
kill -SIGTERM "$PID" || true
```

**Cubrimos:** `ps`, `top`, `&`, `jobs`, `bg`, `fg`, `kill`.

---

## 11) Red y transferencia: ping, curl, wget, scp/rsync (demo segura)
> Para entornos sin Internet, puedes omitir o sustituir por hosts internos.

```bash
// ping (Ctrl+C para parar)
ping -c 2 example.com || true

# curl/wget (cabeceras o descargar a /tmp)
curl -I https://example.com || true
wget -qO- https://example.com | head -n 10 || true

# scp/rsync — ejemplos de sintaxis (requieren host accesible)
# scp archivo usuario@host:/ruta/destino
# rsync -avh ~/lab_cli/datos usuario@host:/backup/datos
```

**Cubrimos:** `ping`, `curl`, `wget`, `scp`, `rsync`.

---

## 12) Programación de tareas: cron y at
```bash
# cron: editar y añadir una tarea que registre la hora cada minuto (demo)
crontab -l 2>/dev/null | cat
( crontab -l 2>/dev/null; echo "* * * * * echo \"tick $(date)\" >> $HOME/lab_cli/logs/cron.log" ) | crontab -
crontab -l | tail -n 3

# at: ejecutar una vez en 2 minutos (puede requerir que el servicio atd esté activo)
# echo 'echo "one-shot $(date)" >> $HOME/lab_cli/logs/at.log' | at now + 2 minutes
```

**Cubrimos:** `crontab`, `at` (sintaxis).

---

## 13) Servicios y logs del sistema (systemctl/journalctl) *(requiere sudo)*
```bash
# Ver estado de un servicio
# systemctl status ssh

# Reiniciar un servicio
# sudo systemctl restart ssh

# Logs
# journalctl -u ssh --since "today"
```

**Cubrimos:** `systemctl`, `journalctl`.

---

## 14) Git (ciclo básico en local)
```bash
cd ~/lab_cli/proyectos/app
git init
echo "hola" > README.md
git add README.md
git commit -m "init"

# Cambios y diff
echo "linea 2" >> README.md
git status
git diff
git add README.md && git commit -m "feat: añade linea 2"
git log --oneline
```

**Cubrimos:** `git init/add/commit/status/diff/log`.

---

## 15) Reto integrador (pipeline de datos reproducible)
**Objetivo:** extraer IPs válidas de `trazas.txt`, contarlas, empaquetar resultados versionados y subirlos a `output` con un symlink “actual”.

```bash
cd ~/lab_cli/proyectos/app

# 1) Extraer IPs únicas y ordenadas
grep -Eo "([0-9]{1,3}\.){3}[0-9]{1,3}" ../../datos/trazas.txt | sort -u > output/ips_v1.txt
wc -l output/ips_v1.txt

# 2) Nueva versión + enlace simbólico 'actual'
cp output/ips_v1.txt output/ips_v2.txt
ln -sfn output/ips_v2.txt output/ips_actual.txt
readlink -f output/ips_actual.txt
ls -l output/ips_*.txt output/ips_actual.txt

# 3) Empaquetar artefactos y dejar huella en Git
tar -czf output/resultados_$(date +%F).tgz output/ips_*.txt
git add output && git commit -m "build: resultados $(date +%F)" && git log --oneline | head -n 5
```

**Cubrimos:** `grep`, `sort -u`, `wc`, `cp`, `ln -sfn`, `readlink`, `ls -l`, `tar`, `git`.

---

## 16) Limpieza opcional
```bash
# ¡Cuidado! elimina todo el laboratorio
rm -rf ~/lab_cli
```

---

### Apéndice: mapa de comandos cubiertos
- **Navegación y ayuda:** `pwd`, `cd`, `ls`, `tree`, `man`, `--help`, `history`, `!!`, `!n`
- **Archivos:** `touch`, `cat`, `nl`, `head`, `tail`, `wc`, `echo`, `printf`, `rm`, `cp`, `mv`
- **Permisos/usuarios:** `chmod`, `umask`, `chown`*, `useradd`*, `userdel`*
- **Búsqueda:** `which`, `whereis`, `find`, `locate`, `updatedb`, `grep`, `grep -r`, `grep -E`
- **Text pipeline:** redirecciones `> >> 2>`, `|`, `tee`, `xargs`, `cut`, `sort`, `uniq`, `sed`, `awk`, `diff`
- **Enlaces y globbing:** `ln`, `ln -s`, `readlink`, `ls -li`, comodines `{ } [ ] ?`
- **Compresión:** `tar`, `gzip/bzip2` (flags), `zip`, `unzip`
- **Sistema y disco:** `df`, `du`, `file`, `stat`
- **Procesos:** `ps`, `top`, `&`, `jobs`, `bg`, `fg`, `kill`
- **Red:** `ping`, `curl`, `wget`, `scp`, `rsync`
- **Tareas programadas:** `crontab`, `at`
- **Servicios y logs:** `systemctl`*, `journalctl`*
- **Control de versiones:** `git`
\* normalmente requiere `sudo` o servicios activos.
